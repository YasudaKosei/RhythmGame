///////////////////////////

VERSION 0.9
Last update: 02/12/2023

///////////////////////////



* LICENSE *

Switch Button icons [Essential pack] © 2023 by Gioele Casazza is licensed under CC BY 4.0: http://creativecommons.org/licenses/by/4.0/?ref=chooser-v1



* LEGAL NOTICE *

Trademarks are property of their respective owners. Nintendo Switch is a trademark of Nintendo.
This project and its creator are not affiliated nor sponsored by Nintendo in any way.

Resources used for this project:

- Inter font by Rasmus Andersson:	https://rsms.me/inter/
- Material Icons by Google:		https://fonts.google.com/icons
- Remix Icon by Remix Design Studio:	https://remixicon.com/



* CONTACTS *

For any kind of questions related to the use of this library or to share feedback and thoughts, please feel free to contact me:

- LinkedIn: 	https://www.linkedin.com/in/gioelecasazza/
- Mail: 	gioele.casazza+design@gmail.com